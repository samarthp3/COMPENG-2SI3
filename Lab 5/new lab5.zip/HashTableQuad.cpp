﻿#include "HashTableQuad.h"
#include <iostream>
#include <random>
using namespace std;

HashTableQuad::HashTableQuad(int maxNum, double load)
{
	this->loadMax = load;
	double tableSize = maxNum / load;
	int smallest_prime = ceil(tableSize);
	smallest_prime = primeCheck(smallest_prime);

	this->table.resize(smallest_prime, NULL);
	this->tableSize = smallest_prime;
	this->noKeys = 0;
}

int HashTableQuad::primeCheck(int p) {
	
	bool smallest_prime = false;

	while (!smallest_prime) {
		bool is_prime = true;
		if (p == 0 || p == 1) {
			is_prime = false;
		}

		for (int i = 2; i <= p / 2; ++i) {
			if (p % i == 0) {
				is_prime = false;
			}
		}

		if (!is_prime) {
			p++;
		}
		else {
			smallest_prime = true;
			break;
		}
	}

	return p;
}

void HashTableQuad::insert(int n)
{
	if (isIn(n) == false) {
		int hash_function = n % getTableSize();
		int probe_index = 0;

		while (this->table[hash_function] != 0) {
			probe_index++;
			hash_function = (n + (probe_index * probe_index)) % getTableSize();

			if (probe_index > getTableSize()) {
				return;
			}
		}

		this->table[hash_function] = n;
		this->noKeys++;

		if ((((double)getNumKeys() + 1) / (double)getTableSize() > getMaxLoadFactor())) {
			this->rehash();
		}
	}

}

void HashTableQuad::rehash()
{
	int new_hash_size = this->primeCheck(this->getTableSize() * 2);

	vector<int> this_copy_table = this->table;
	vector<int> new_table(new_hash_size, 0);

	this->table = new_table;
	this->tableSize = new_hash_size;
	this->noKeys = 0;

	for (int i = 0; i < this_copy_table.size(); i++) {
		if (this_copy_table[i] != 0) {
			this->insert(this_copy_table[i]);

		}
	}
}

bool HashTableQuad::isIn(int n)
{
	if (getTableSize() > 0) {

		int hash_function = n % getTableSize();
		int probe_index = 0;

		while (this->table[hash_function] != 0) {

			if (this->table[hash_function] == n) {
				return true;
			}
			else {
				probe_index++;
				hash_function = (n + (probe_index * probe_index)) % getTableSize();
			}
			if (probe_index > getTableSize()) {
				return false;
			}
		}
	}
	return false;
}

void HashTableQuad::printKeys()
{
	for (int i = 0; i < getTableSize(); i++) {
		if (this->table[i] != 0) {
			cout << table[i] << ", ";
		}
	}
}

void HashTableQuad::printKeysAndIndexes()
{
	for (int i = 0; i < getTableSize(); i++) {
		if (this->table[i] != 0) {
			cout << i << "-";
			cout << table[i] << ", ";

		}
	}
}

int HashTableQuad::getNumKeys() {
	return this->noKeys;
}

int HashTableQuad::getTableSize() {
	return this->tableSize;
}

double HashTableQuad::getMaxLoadFactor() {
	return this->loadMax;
}

int HashTableQuad::countInst(int n) {
	if (isIn(n) == true) {
		return 0;
	}

	int hash_function = n % getTableSize();
	int probe_index = 1;

	while (this->table[hash_function] != 0) {
		probe_index++;
		hash_function = (n + (probe_index * probe_index)) % getTableSize();
	}

	this->table[hash_function] = n;
	this->noKeys++;

	return probe_index;
}

std::vector<double> HashTableQuad::simProbeSuccess()
{
	vector<double> result;
	int probes = 0;
	double average_probes = 0;
	double total_average_probes = 0;

	for (double i = 0.1; i < 1; i += 0.1) {
		for (int j = 0; j < 100; j++) {

			HashTableQuad sim_prob_table(10000, i);

			probes = 0;
			std::default_random_engine generator;
			std::uniform_int_distribution<int> distribution;

			while (sim_prob_table.getNumKeys() != 10000) {
				probes += sim_prob_table.countInst(distribution(generator));
			}

			average_probes += double(probes) / double(sim_prob_table.getNumKeys());
		}
		total_average_probes = average_probes / 100.0;
		average_probes = 0;
		result.push_back(total_average_probes);
	}
	return result;
}